<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * RostersFixture
 */
class RostersFixture extends TestFixture
{
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id' => 1,
                'users_id' => 1,
                'start_time' => '2024-01-10 18:52:35',
                'end_time' => '2024-01-10 18:52:35',
                'status' => 1,
                'reason' => 'Lorem ipsum dolor sit amet',
                'deleted' => '2024-01-10 18:52:35',
                'created' => 1704880355,
                'modified' => 1704880355,
                'created_user' => 'Lorem ipsum dolor sit amet',
                'modified_user' => 'Lorem ipsum dolor sit amet',
            ],
        ];
        parent::init();
    }
}
