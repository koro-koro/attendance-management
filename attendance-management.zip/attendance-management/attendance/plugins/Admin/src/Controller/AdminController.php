<?php
declare(strict_types=1);

namespace Admin\Controller;

class AdminController extends AppController
{
}